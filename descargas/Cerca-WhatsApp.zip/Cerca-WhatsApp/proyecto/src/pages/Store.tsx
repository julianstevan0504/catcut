import { useState, useEffect, useRef } from "react";
import type { FormEvent } from "react";
import {
  ArrowDownToLine,
  ArrowRight,
  Bot,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Grid2X2,
  History,
  List,
  LoaderCircle,
  MessageCircle,
  Package,
  Pencil,
  Plus,
  Settings,
  ShoppingBag,
  Sparkles,
  Trash2,
  UserRound,
  Upload,
} from "lucide-react";
import {
  api,
  dateLabel,
  exportCsv,
  money,
  post,
  put,
  relativeTime,
  useResource,
} from "../api";
import { useApp } from "../context";
import {
  Avatar,
  EmptyState,
  ErrorState,
  Modal,
  PageHeading,
  SaveButton,
  SearchBox,
  Spinner,
  StatusBadge,
} from "../components";
import type { Activity, Order, Product } from "../types";
import { ImportCatalog } from "../Workbench";

type ProductDraft = Omit<Product, "id">;
const newProduct: ProductDraft = {
  name: "",
  sku: "",
  description: "",
  category: "General",
  kind: "product",
  ingredients: "",
  allergens: "",
  price: 0,
  stock: 0,
  color: "sage",
};

export function Products({ initialId }: { initialId?: string } = {}) {
  const { version, refresh, notify } = useApp();
  const { data, loading, error, reload } = useResource<Product[]>(
    "/products",
    version,
  );
  const [search, setSearch] = useState(""),
    [category, setCategory] = useState("all"),
    [view, setView] = useState("grid");
  const [editing, setEditing] = useState<Product | "new" | null>(null),
    [deleting, setDeleting] = useState<Product | null>(null),
    [busy, setBusy] = useState(false);
  const [importing, setImporting] = useState(false),
    [stockFilter, setStockFilter] = useState("all");
  const opened = useRef("");
  useEffect(() => {
    if (initialId && data && opened.current !== initialId) {
      const p = data.find((p) => p.id === initialId);
      if (p) {
        opened.current = initialId;
        setEditing(p);
      }
    }
  }, [data, initialId]);
  const products =
    data?.filter(
      (p) =>
        (category === "all" || p.category === category) &&
        (stockFilter === "all" ||
          (stockFilter === "available" && p.stock > 0) ||
          (stockFilter === "low" && p.stock > 0 && p.stock <= 3) ||
          (stockFilter === "empty" && p.stock === 0)) &&
        `${p.name} ${p.sku}`.toLowerCase().includes(search.toLowerCase()),
    ) ?? [];
  const categories = [...new Set(data?.map((p) => p.category) ?? [])];
  async function remove() {
    if (!deleting) return;
    setBusy(true);
    try {
      await api(`/products/${deleting.id}`, { method: "DELETE", body: "{}" });
      notify("Producto eliminado del catálogo.");
      refresh();
      setDeleting(null);
    } catch (e) {
      notify((e as Error).message, true);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeading
        eyebrow="LO QUE HACE ESPECIAL A TU TIENDA"
        title="Tu catálogo, al día."
        subtitle="Precios y stock reales para respuestas que tus clientes pueden confiar."
        action={
          <>
            <button
              className="button secondary"
              onClick={() => setImporting(true)}
            >
              <Upload size={16} /> Importar CSV
            </button>
            <button
              className="button secondary"
              disabled={!products.length}
              onClick={() =>
                exportCsv("catalogo-cerca.csv", [
                  [
                    "nombre",
                    "sku",
                    "descripcion",
                    "categoria",
                    "precio",
                    "stock",
                    "color",
                    "tipo",
                    "ingredientes",
                    "alergenos",
                  ],
                  ...products.map((p) => [
                    p.name,
                    p.sku,
                    p.description,
                    p.category,
                    p.price,
                    p.stock,
                    p.color,
                    p.kind ?? "product",
                    p.ingredients ?? "",
                    p.allergens ?? "",
                  ]),
                ])
              }
            >
              <ArrowDownToLine size={16} /> Exportar
            </button>
            <button
              className="button primary"
              onClick={() => setEditing("new")}
            >
              <Plus size={17} /> Agregar producto
            </button>
          </>
        }
      />
      <div className="catalog-summary">
        <span>
          <span className="summary-icon sage">
            <Package size={18} />
          </span>
          <strong>{data?.length ?? 0}</strong> productos en tu tienda
        </span>
        <span className="summary-divider" />
        <span>
          <span className="status-dot" />
          {data?.filter((p) => p.stock > 0).length ?? 0} disponibles
        </span>
        <span className="summary-divider" />
        <span>
          <span className="status-dot amber" />
          {data?.filter((p) => p.stock === 0).length ?? 0} agotados
        </span>
        <span className="catalog-ai-note">
          <Sparkles size={14} /> Tu asistente consulta este catálogo
        </span>
      </div>
      <div className="list-toolbar">
        <SearchBox
          value={search}
          onChange={setSearch}
          placeholder="Buscar por producto o SKU..."
        />
        <div className="toolbar-right">
          <select
            aria-label="Filtrar productos por stock"
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value)}
          >
            <option value="all">Todo el inventario</option>
            <option value="available">Disponibles</option>
            <option value="low">Últimas unidades</option>
            <option value="empty">Agotados</option>
          </select>
          <select
            aria-label="Filtrar categoría"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
          <div className="view-switch">
            <button
              className={view === "grid" ? "active" : ""}
              aria-label="Ver productos en cuadrícula"
              onClick={() => setView("grid")}
            >
              <Grid2X2 size={17} />
            </button>
            <button
              className={view === "list" ? "active" : ""}
              aria-label="Ver productos en lista"
              onClick={() => setView("list")}
            >
              <List size={18} />
            </button>
          </div>
        </div>
      </div>
      {loading ? (
        <Spinner />
      ) : error ? (
        <ErrorState message={error} retry={reload} />
      ) : !products.length ? (
        <div className="card">
          <EmptyState
            title={
              data?.length
                ? "No encontramos ese producto"
                : "Tu próximo favorito empieza aquí"
            }
            description={
              data?.length
                ? "Prueba con otro nombre o cambia la categoría."
                : "Agrega tu primer producto. El asistente podrá consultar su precio y disponibilidad al instante."
            }
            action={
              !data?.length && (
                <button
                  className="button primary"
                  onClick={() => setEditing("new")}
                >
                  <Plus size={16} /> Crear mi primer producto
                </button>
              )
            }
          />
        </div>
      ) : (
        <div className={`product-grid ${view === "list" ? "list-view" : ""}`}>
          {products.map((product) => (
            <article className="product-card" key={product.id}>
              <div className={`product-art ${product.color}`}>
                <span className="product-category">{product.category}</span>
                <ProductArt
                  category={product.category}
                  name={product.name}
                  kind={product.kind}
                />
                <span
                  className={`stock-badge ${!product.stock ? "empty" : product.stock <= 3 ? "low" : ""}`}
                >
                  <i />
                  {!product.stock
                    ? "Agotado"
                    : product.stock <= 3
                      ? "Últimas unidades"
                      : "Disponible"}
                </span>
              </div>
              <div className="product-body">
                <span className="product-sku">{product.sku}</span>
                <h3>{product.name}</h3>
                <p>{product.description}</p>
                {(product.kind === "dish" || product.kind === "drink") && (
                  <div className="product-food-details">
                    <span>
                      <b>
                        {product.kind === "dish"
                          ? "Plato del menú"
                          : "Bebida del menú"}
                      </b>
                    </span>
                    <span
                      className={
                        product.ingredients ? "" : "missing-ingredients"
                      }
                    >
                      {product.ingredients
                        ? `Ingredientes: ${product.ingredients}`
                        : "Ingredientes pendientes de confirmar"}
                    </span>
                    {product.allergens && (
                      <span>Alérgenos: {product.allergens}</span>
                    )}
                  </div>
                )}
                <div className="product-bottom">
                  <span>
                    <strong>{money(product.price)}</strong>
                    <small>COP</small>
                  </span>
                  <span className="product-stock">
                    <Package size={14} />
                    {product.stock} uds.
                  </span>
                </div>
              </div>
              <div className="product-actions">
                <button onClick={() => setEditing(product)}>
                  <Pencil size={14} /> Editar producto
                </button>
                <button
                  className="icon-button danger"
                  aria-label={`Eliminar ${product.name}`}
                  onClick={() => setDeleting(product)}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
      <div className="catalog-footnote">
        <Sparkles size={15} />
        <span>
          Los cambios de precio y stock se aplican a las próximas respuestas del
          asistente. El inventario se gestiona manualmente.
        </span>
      </div>
      {editing && (
        <Modal
          title={
            editing === "new"
              ? "Un nuevo favorito para tu tienda."
              : "Cada detalle cuenta."
          }
          description="Tu asistente usará esta información para responder a los clientes."
          onClose={() => setEditing(null)}
        >
          <ProductForm
            product={editing === "new" ? undefined : editing}
            onDone={() => {
              setEditing(null);
              refresh();
            }}
          />
        </Modal>
      )}
      {importing && (
        <ImportCatalog
          onClose={() => setImporting(false)}
          onDone={() => {
            setImporting(false);
            refresh();
          }}
        />
      )}
      {deleting && (
        <Modal
          title="¿Eliminar este producto?"
          description={`${deleting.name} dejará de aparecer en las consultas del asistente.`}
          onClose={() => setDeleting(null)}
        >
          <div className="modal-actions">
            <button
              className="button secondary"
              onClick={() => setDeleting(null)}
            >
              Conservar producto
            </button>
            <button
              className="button danger-button"
              disabled={busy}
              onClick={() => void remove()}
            >
              {busy ? (
                <LoaderCircle size={16} className="spin" />
              ) : (
                <Trash2 size={16} />
              )}{" "}
              Eliminar
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}

function ProductForm({
  product,
  onDone,
}: {
  product?: Product;
  onDone: () => void;
}) {
  const { notify } = useApp();
  const [draft, setDraft] = useState<ProductDraft>(product ?? newProduct),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const change = (key: keyof ProductDraft, value: string | number) =>
    setDraft((d) => ({ ...d, [key]: value }));
  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      if (product) await put(`/products/${product.id}`, draft);
      else await post("/products", draft);
      notify(
        product
          ? "Producto actualizado. Tu asistente ya conoce los cambios."
          : "Producto agregado a tu catálogo.",
      );
      onDone();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="modal-form" onSubmit={(e) => void save(e)}>
      <label className="field-label">
        Nombre del producto
        <input
          required
          value={draft.name}
          onChange={(e) => change("name", e.target.value)}
          maxLength={100}
          placeholder="Ej. Camiseta Essential"
        />
      </label>
      <div className="form-row">
        <label className="field-label">
          SKU
          <input
            required
            value={draft.sku}
            onChange={(e) => change("sku", e.target.value)}
            maxLength={40}
            placeholder="CE-001"
          />
        </label>
        <label className="field-label">
          Categoría
          <input
            value={draft.category}
            onChange={(e) => change("category", e.target.value)}
            maxLength={80}
            required
            placeholder="Ej. Ropa"
          />
        </label>
      </div>
      <label className="field-label">
        Tipo de ficha
        <select
          value={draft.kind ?? "product"}
          onChange={(e) => change("kind", e.target.value)}
        >
          <option value="product">Producto</option>
          <option value="dish">Plato del menú</option>
          <option value="drink">Bebida del menú</option>
        </select>
      </label>
      <div className="form-row">
        <label className="field-label">
          Ingredientes confirmados
          <textarea
            rows={3}
            maxLength={1000}
            value={draft.ingredients ?? ""}
            onChange={(e) => change("ingredients", e.target.value)}
            placeholder="Ej. Agua, limón y azúcar. Solo información confirmada."
          />
        </label>
        <label className="field-label">
          Alérgenos y posibles trazas
          <textarea
            rows={3}
            maxLength={500}
            value={draft.allergens ?? ""}
            onChange={(e) => change("allergens", e.target.value)}
            placeholder="Ej. Contiene leche y trigo. Si no lo sabes, deja vacío."
          />
        </label>
      </div>
      <p className="form-hint">
        Si faltan ingredientes o alérgenos, el asistente pedirá confirmarlos al
        equipo. Stock 0 significa agotado.
      </p>
      <label className="field-label">
        Descripción
        <textarea
          required={false}
          value={draft.description}
          onChange={(e) => change("description", e.target.value)}
          maxLength={1000}
          rows={3}
          placeholder="Materiales, tallas, colores y detalles que tus clientes preguntan."
        />
      </label>
      <div className="form-row">
        <label className="field-label">
          Precio en pesos colombianos
          <input
            type="number"
            min={0}
            max={1000000000}
            step={1}
            required
            value={draft.price}
            onChange={(e) => change("price", Number(e.target.value))}
          />
        </label>
        <label className="field-label">
          Unidades disponibles
          <input
            type="number"
            min={0}
            max={1000000}
            step={1}
            required
            value={draft.stock}
            onChange={(e) => change("stock", Number(e.target.value))}
          />
        </label>
      </div>
      <label className="field-label">Color de la ficha</label>
      <div className="color-options">
        {[
          ["sage", "Verde salvia"],
          ["sand", "Arena"],
          ["peach", "Durazno"],
          ["lavender", "Lavanda"],
        ].map(([color, label]) => (
          <button
            type="button"
            key={color}
            aria-label={label}
            aria-pressed={draft.color === color}
            className={`color-option ${color} ${draft.color === color ? "selected" : ""}`}
            onClick={() => change("color", color)}
          >
            {draft.color === color && <CheckCircle2 size={19} />}
          </button>
        ))}
      </div>
      {error && (
        <div className="inline-error" role="alert">
          {error}
        </div>
      )}
      <div className="modal-actions">
        <button type="button" className="button secondary" onClick={onDone}>
          Cancelar
        </button>
        <SaveButton busy={busy}>
          {product ? "Guardar producto" : "Agregar producto"}
        </SaveButton>
      </div>
    </form>
  );
}

function ProductArt({
  category,
  name,
  kind,
}: {
  category: string;
  name: string;
  kind?: Product["kind"];
}) {
  return (
    <svg
      className="product-illustration"
      viewBox="0 0 180 150"
      aria-hidden="true"
    >
      <ellipse
        cx="90"
        cy="129"
        rx="46"
        ry="7"
        fill="currentColor"
        opacity=".08"
      />
      {kind === "drink" ? (
        <g stroke="currentColor" strokeWidth="2" fill="none">
          <path
            d="M61 46H119L111 121H69Z"
            fill="currentColor"
            fillOpacity=".12"
          />
          <path d="M76 94 96 27H121M64 70Q90 82 116 70" />
          <circle
            cx="111"
            cy="44"
            r="17"
            fill="currentColor"
            fillOpacity=".09"
          />
          <path d="M111 28V59M95 44H127" />
        </g>
      ) : kind === "dish" ? (
        <g stroke="currentColor" strokeWidth="2" fill="none">
          <ellipse
            cx="90"
            cy="86"
            rx="54"
            ry="34"
            fill="currentColor"
            fillOpacity=".10"
          />
          <ellipse cx="90" cy="83" rx="41" ry="25" />
          <path d="M34 33V64Q34 73 27 73V122M21 33V64M27 33V122M147 32V123M147 32Q165 48 147 71" />
          <path d="M70 80Q82 67 93 80T111 82M76 92Q90 103 105 91M79 44Q69 35 79 26M95 44Q85 35 95 26" />
        </g>
      ) : /pantal[oó]n/i.test(name) ? (
        <>
          <path
            d="M62 26H118L126 122H98L90 67 82 122H54Z"
            fill="currentColor"
            opacity=".16"
          />
          <path
            d="M62 26H118L126 122H98L90 67 82 122H54ZM61 40H119M90 27V54M64 41Q64 59 58 60M116 41Q116 59 122 60"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </>
      ) : /gorra/i.test(name) ? (
        <>
          <path
            d="M49 90Q49 37 91 37T133 90L151 104Q121 117 88 109L42 102Z"
            fill="currentColor"
            opacity=".16"
          />
          <path
            d="M49 90Q49 37 91 37T133 90M49 90Q97 77 133 90L151 104Q121 117 88 109L42 102ZM91 37Q76 54 79 84M95 35H101"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </>
      ) : /collar/i.test(name) ? (
        <>
          <path
            d="M52 28C32 82 60 98 90 115C120 98 148 82 128 28"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
          />
          <path
            d="M90 97 104 112 90 129 76 112Z"
            fill="currentColor"
            opacity=".2"
          />
          <path
            d="M90 97 104 112 90 129 76 112ZM54 28Q90 17 126 28"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          />
          <circle cx="90" cy="111" r="3" fill="currentColor" />
        </>
      ) : /vela/i.test(name) ? (
        <>
          <rect
            x="59"
            y="59"
            width="62"
            height="62"
            rx="7"
            fill="currentColor"
            opacity=".17"
          />
          <path
            d="M59 64Q90 73 121 64M66 61Q90 55 114 61M90 60V51M91 47Q109 31 91 18Q74 35 91 47Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          />
          <rect
            x="59"
            y="59"
            width="62"
            height="62"
            rx="7"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          />
        </>
      ) : /ropa/i.test(category) ? (
        <>
          <path
            d="M63 30 38 49 53 72 66 64 63 119H117L114 64 127 72 142 49 117 30 103 24Q90 40 77 24Z"
            fill="currentColor"
            opacity=".18"
          />
          <path
            d="M63 30 38 49 53 72 66 64 63 119H117L114 64 127 72 142 49 117 30 103 24Q90 40 77 24Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path
            d="M77 25Q90 50 103 25M67 110H113"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
          />
        </>
      ) : /calzado/i.test(category) ? (
        <>
          <path
            d="M37 83 42 49 65 59 86 52 103 78 137 89Q149 95 143 114H39Q30 105 37 83Z"
            fill="currentColor"
            opacity=".18"
          />
          <path
            d="M37 83 42 49 65 59 86 52 103 78 137 89Q149 95 143 114H39Q30 105 37 83ZM35 102H145M82 65 72 75M89 74 80 83M96 83 88 91"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </>
      ) : /accesorio/i.test(category) ? (
        <>
          <path d="M48 60H132L140 120H40Z" fill="currentColor" opacity=".18" />
          <path
            d="M48 60H132L140 120H40ZM67 64V47C67 15 113 15 113 47V64M54 74H126M82 74V95H98V74"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <circle cx="90" cy="85" r="2" fill="currentColor" />
        </>
      ) : (
        <>
          <path
            d="M44 52 90 28 136 52V104L90 128 44 104Z"
            fill="currentColor"
            opacity=".16"
          />
          <path
            d="M44 52 90 28 136 52V104L90 128 44 104ZM44 52 90 77 136 52M90 77V128M67 40 113 65V83"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          />
        </>
      )}
    </svg>
  );
}

const orderStatuses = [
  ["confirmed", "Confirmado"],
  ["preparing", "Preparando"],
  ["shipped", "En camino"],
  ["delivered", "Entregado"],
  ["cancelled", "Cancelado"],
];
type OrderDraft = Omit<Order, "id" | "created_at" | "updated_at">;
const newOrder: OrderDraft = {
  code: "",
  customer: "",
  phone: "+57",
  status: "confirmed",
  total: 0,
  items: "",
  tracking_number: "",
  tracking_url: "",
};

export function Orders({ initialId }: { initialId?: string } = {}) {
  const { version, refresh, notify } = useApp();
  const { data, loading, error, reload } = useResource<Order[]>(
    "/orders",
    version,
  );
  const [search, setSearch] = useState(""),
    [status, setStatus] = useState("all"),
    [editing, setEditing] = useState<Order | "new" | null>(null);
  const opened = useRef("");
  useEffect(() => {
    if (initialId && data && opened.current !== initialId) {
      const o = data.find((o) => o.id === initialId);
      if (o) {
        opened.current = initialId;
        setEditing(o);
      }
    }
  }, [data, initialId]);
  const orders =
    data?.filter(
      (o) =>
        (status === "all" || o.status === status) &&
        `${o.code} ${o.customer} ${o.phone}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    ) ?? [];
  function exportOrders() {
    exportCsv("pedidos-cerca.csv", [
      [
        "Pedido",
        "Cliente",
        "Teléfono",
        "Estado",
        "Total COP",
        "Productos",
        "Guía",
        "Seguimiento",
        "Fecha",
      ],
      ...orders.map((o) => [
        o.code,
        o.customer,
        o.phone,
        orderStatuses.find((s) => s[0] === o.status)?.[1] ?? o.status,
        o.total,
        o.items,
        o.tracking_number,
        o.tracking_url,
        o.created_at,
      ]),
    ]);
    notify("Pedidos exportados.");
  }
  return (
    <>
      <PageHeading
        eyebrow="DEL PRIMER HOLA A LA ENTREGA"
        title="Cada pedido, en su lugar."
        subtitle="Actualiza los estados y deja que tu asistente se encargue del «¿cómo va lo mío?»."
        action={
          <>
            <button
              className="button secondary"
              onClick={exportOrders}
              disabled={!orders.length}
            >
              <ArrowDownToLine size={16} /> Exportar
            </button>
            <button
              className="button primary"
              onClick={() => setEditing("new")}
            >
              <Plus size={17} /> Registrar pedido
            </button>
          </>
        }
      />
      <div className="order-stats">
        {[
          {
            label: "Pedidos registrados",
            value: data?.length ?? 0,
            icon: ShoppingBag,
          },
          {
            label: "En preparación",
            value:
              data?.filter((o) => ["confirmed", "preparing"].includes(o.status))
                .length ?? 0,
            icon: Package,
          },
          {
            label: "En camino",
            value: data?.filter((o) => o.status === "shipped").length ?? 0,
            icon: ArrowRight,
          },
          {
            label: "Entregados",
            value: data?.filter((o) => o.status === "delivered").length ?? 0,
            icon: CheckCircle2,
          },
        ].map((s) => (
          <div className="mini-stat" key={s.label}>
            <s.icon size={20} />
            <span>
              <strong>{s.value}</strong>
              <small>{s.label}</small>
            </span>
          </div>
        ))}
      </div>
      <section className="card orders-card">
        <div className="list-toolbar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Buscar pedido, cliente o teléfono..."
          />
          <select
            aria-label="Filtrar pedidos por estado"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="all">Todos los estados</option>
            {orderStatuses.map(([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </select>
        </div>
        {loading ? (
          <Spinner />
        ) : error ? (
          <ErrorState message={error} retry={reload} />
        ) : orders.length ? (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>PEDIDO</th>
                  <th>CLIENTE</th>
                  <th>PRODUCTOS</th>
                  <th>ESTADO</th>
                  <th>TOTAL</th>
                  <th>
                    <span className="sr-only">Acciones</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o, i) => (
                  <tr key={o.id}>
                    <td>
                      <strong className="order-code">#{o.code}</strong>
                      <small>{dateLabel(o.created_at)}</small>
                    </td>
                    <td>
                      <div className="table-contact">
                        <Avatar name={o.customer} index={i} />
                        <span>
                          <strong>{o.customer}</strong>
                          <small>{o.phone}</small>
                        </span>
                      </div>
                    </td>
                    <td>
                      <span className="order-items">{o.items}</span>
                      {o.tracking_number && (
                        <small>Guía: {o.tracking_number}</small>
                      )}
                    </td>
                    <td>
                      <StatusBadge status={o.status} />
                    </td>
                    <td>
                      <strong>{money(o.total)}</strong>
                      <small>COP</small>
                    </td>
                    <td>
                      <button
                        className="icon-button"
                        title="Editar pedido"
                        aria-label={`Editar pedido ${o.code}`}
                        onClick={() => setEditing(o)}
                      >
                        <Pencil size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            title={
              data?.length
                ? "Ningún pedido con ese filtro"
                : "Acompaña cada compra hasta el final"
            }
            description={
              data?.length
                ? "Prueba otro código, nombre o estado."
                : "Registra tu primer pedido para que tus clientes puedan consultar su estado por WhatsApp."
            }
            action={
              !data?.length && (
                <button
                  className="button primary"
                  onClick={() => setEditing("new")}
                >
                  <Plus size={16} /> Registrar pedido
                </button>
              )
            }
          />
        )}
        <div className="table-footer">
          <span>
            {orders.length} {orders.length === 1 ? "pedido" : "pedidos"}
          </span>
          <span>
            <Sparkles size={13} /> El asistente consulta el estado actualizado
          </span>
        </div>
      </section>
      <div className="info-note order-privacy">
        <UserRound size={18} />
        <p>
          Para proteger a tus clientes, el código del pedido debe coincidir con
          el número de WhatsApp registrado. La guía y el enlace se agregan
          manualmente.
        </p>
      </div>
      {editing && (
        <Modal
          title={
            editing === "new"
              ? "Un pedido. Una nueva ilusión."
              : `Actualiza el pedido ${editing.code}`
          }
          description="Cada cambio estará disponible para las próximas consultas del cliente."
          onClose={() => setEditing(null)}
          wide
        >
          <OrderForm
            order={editing === "new" ? undefined : editing}
            onDone={() => {
              setEditing(null);
              refresh();
            }}
          />
        </Modal>
      )}
    </>
  );
}

function OrderForm({ order, onDone }: { order?: Order; onDone: () => void }) {
  const { notify } = useApp();
  const [draft, setDraft] = useState<OrderDraft>(order ?? newOrder),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const change = (key: keyof OrderDraft, value: string | number) =>
    setDraft((d) => ({ ...d, [key]: value }));
  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      if (order) await put(`/orders/${order.id}`, draft);
      else await post("/orders", draft);
      notify(
        order ? "Estado del pedido actualizado." : "Nuevo pedido registrado.",
      );
      onDone();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form className="modal-form" onSubmit={(e) => void save(e)}>
      <div className="form-row">
        <label className="field-label">
          Código del pedido
          <input
            required
            placeholder="LC-1045"
            value={draft.code}
            onChange={(e) => change("code", e.target.value)}
            maxLength={30}
            pattern="[A-Za-z]{1,8}-[0-9]{2,20}"
          />
          <small>Letras, guion y números. Ejemplo: LC-1045.</small>
        </label>
        <label className="field-label">
          Estado
          <select
            value={draft.status}
            onChange={(e) => change("status", e.target.value)}
          >
            {orderStatuses.map(([id, label]) => (
              <option value={id} key={id}>
                {label}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="form-row">
        <label className="field-label">
          Nombre del cliente
          <input
            required
            maxLength={100}
            value={draft.customer}
            onChange={(e) => change("customer", e.target.value)}
          />
        </label>
        <label className="field-label">
          WhatsApp del cliente
          <input
            type="tel"
            required
            value={draft.phone}
            onChange={(e) => change("phone", e.target.value)}
            maxLength={30}
            placeholder="+573001112233"
          />
          <small>Incluye el código del país, por ejemplo +57.</small>
        </label>
      </div>
      <label className="field-label">
        Productos del pedido
        <textarea
          rows={2}
          required
          maxLength={1000}
          value={draft.items}
          onChange={(e) => change("items", e.target.value)}
          placeholder="1 × Bolso Alba"
        />
      </label>
      <div className="form-row">
        <label className="field-label">
          Total en pesos colombianos
          <input
            type="number"
            required
            min={0}
            max={1000000000}
            step={1}
            value={draft.total}
            onChange={(e) => change("total", Number(e.target.value))}
          />
        </label>
        <label className="field-label">
          Número de guía · opcional
          <input
            maxLength={100}
            value={draft.tracking_number}
            onChange={(e) => change("tracking_number", e.target.value)}
          />
        </label>
      </div>
      <label className="field-label">
        Enlace de seguimiento · opcional
        <input
          type="url"
          placeholder="https://transportadora.com/seguimiento/..."
          maxLength={1000}
          value={draft.tracking_url}
          onChange={(e) => change("tracking_url", e.target.value)}
        />
      </label>
      {error && (
        <div className="inline-error" role="alert">
          {error}
        </div>
      )}
      <div className="modal-actions">
        <button type="button" className="button secondary" onClick={onDone}>
          Cancelar
        </button>
        <SaveButton busy={busy}>
          {order ? "Actualizar pedido" : "Registrar pedido"}
        </SaveButton>
      </div>
    </form>
  );
}

export function ActivityLog() {
  const { version, notify } = useApp();
  const { data, loading, error, reload } = useResource<Activity[]>(
    "/activities",
    version,
    10000,
  );
  const [search, setSearch] = useState(""),
    [filter, setFilter] = useState("all");
  const rows =
    data?.filter(
      (a) =>
        (filter === "all" || a.action.startsWith(filter)) &&
        `${a.description} ${a.actor}`
          .toLowerCase()
          .includes(search.toLowerCase()),
    ) ?? [];
  const iconFor = (action: string) =>
    action.startsWith("assistant")
      ? Bot
      : action.startsWith("message") || action.startsWith("conversation")
        ? MessageCircle
        : action.startsWith("product")
          ? Package
          : action.startsWith("order")
            ? ShoppingBag
            : action.startsWith("auth")
              ? UserRound
              : Settings;
  function download() {
    exportCsv("actividad-cerca.csv", [
      ["Fecha", "Acción", "Descripción", "Responsable"],
      ...rows.map((a) => [a.created_at, a.action, a.description, a.actor]),
    ]);
    notify("Registro de actividad exportado.");
  }
  return (
    <>
      <PageHeading
        eyebrow="TRANSPARENCIA, EN CADA PASO"
        title="Nada se pierde de vista."
        subtitle="Un registro de las respuestas, los cambios y la actividad de tu tienda."
        action={
          <button
            className="button secondary"
            onClick={download}
            disabled={!rows.length}
          >
            <ArrowDownToLine size={16} /> Exportar registro
          </button>
        }
      />
      <div className="activity-intro">
        <span className="summary-icon sage">
          <History size={21} />
        </span>
        <div>
          <strong>Todo lo que pasa, queda aquí.</strong>
          <p>
            Respuestas automáticas, atención humana, inventario, pedidos y
            accesos a tu cuenta.
          </p>
        </div>
        <span>
          <span className="status-dot" /> Registro activo
        </span>
      </div>
      <section className="card activity-card">
        <div className="list-toolbar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Buscar en la actividad..."
          />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            aria-label="Filtrar tipo de actividad"
          >
            <option value="all">Toda la actividad</option>
            <option value="assistant">Asistente</option>
            <option value="message">Mensajes</option>
            <option value="conversation">Conversaciones</option>
            <option value="product">Productos</option>
            <option value="order">Pedidos</option>
            <option value="auth">Accesos</option>
            <option value="integration">WhatsApp Business</option>
            <option value="settings">Configuración</option>
          </select>
        </div>
        {loading ? (
          <Spinner />
        ) : error ? (
          <ErrorState message={error} retry={reload} />
        ) : rows.length ? (
          <div className="activity-timeline">
            {rows.map((a, i) => {
              const Icon = iconFor(a.action);
              return (
                <div key={a.id}>
                  {(i === 0 ||
                    rows[i - 1].created_at.slice(0, 10) !==
                      a.created_at.slice(0, 10)) && (
                    <div className="activity-date">
                      <Clock3 size={13} />
                      {dateLabel(a.created_at)}
                    </div>
                  )}
                  <div className="activity-row">
                    <span
                      className={`activity-event-icon ${a.action.endsWith("failed") ? "failure" : ""}`}
                    >
                      <Icon size={18} />
                    </span>
                    <div>
                      <p>{a.description}</p>
                      <span>
                        {a.actor} <i /> {a.action}
                      </span>
                    </div>
                    <small>{relativeTime(a.created_at)}</small>
                    <ChevronRight size={15} />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            title="Sin actividad por aquí"
            description="Las acciones de tu tienda aparecerán en este registro. Prueba cambiando el filtro si ya tienes actividad."
          />
        )}
        <div className="table-footer">
          <span>{rows.length} eventos visibles</span>
          <span>Hasta los 200 eventos más recientes</span>
        </div>
      </section>
    </>
  );
}
