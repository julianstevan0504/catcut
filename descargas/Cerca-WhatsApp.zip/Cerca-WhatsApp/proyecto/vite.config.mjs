import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  define: { __CERCA_STANDALONE__: 'false' },
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    proxy: { "/api": "http://127.0.0.1:3000", "/media": "http://127.0.0.1:3000" },
  },
});
