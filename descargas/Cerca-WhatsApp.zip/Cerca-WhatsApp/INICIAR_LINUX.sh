#!/bin/sh
set -eu
cd "$(CDPATH= cd -P "$(dirname "$0")" && pwd)/proyecto"
if ! command -v node >/dev/null 2>&1; then
  echo "Necesitas instalar Node.js 24 o superior desde https://nodejs.org/"
  exit 1
fi
exec node scripts/start-local.mjs
