@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Instala Node.js 24 o superior desde https://nodejs.org/
  pause
  exit /b 1
)
node "proyecto\scripts\start-local.mjs"
if errorlevel 1 (
  echo Revisa el mensaje anterior para completar el inicio.
  pause
  exit /b 1
)
