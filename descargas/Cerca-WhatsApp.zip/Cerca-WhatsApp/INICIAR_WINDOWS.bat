@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Necesitas instalar Node.js 24 o superior desde https://nodejs.org/
  echo Despues de instalarlo, vuelve a abrir este archivo.
  pause
  exit /b 1
)
node "proyecto\scripts\start-local.mjs"
if errorlevel 1 (
  echo.
  echo No se pudo iniciar Cerca. Revisa el mensaje anterior.
  pause
  exit /b 1
)
